# Read text from a file, and count the occurence of words in that text
# Example:
# count_words("The cake is done. It is a big cake!") 
# --> {"cake":2, "big":1, "is":2, "the":1, "a":1, "it":1}

def read_file_content(filename):
   
    
   with open('the-zen-of-python.txt') as f:
    contents = f.read()
    print(contents)


def count_words():
    text = read_file_content('the-zen-of-python.txt')
return counts
print( word_count )
print(len(dict1))

    return {"as": 10, "would": 20}